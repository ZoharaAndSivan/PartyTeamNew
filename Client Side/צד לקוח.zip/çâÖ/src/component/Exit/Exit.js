const Exit = () => {
   return (<>
      <p>
         תודה שבחרתם בנו להקל לכם על אירגון האירוע שלכם
   </p>
   </>)
}


export default Exit;