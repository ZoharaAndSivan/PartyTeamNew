import { useNavigate } from "react-router";

const Advert = () => {
    let nav = useNavigate();
    return (
        <>
            <h1> פרסומותתת </h1>
         
        </>
    )
}
export default Advert;                     