const Statictics = (props) => {
    let detalis ={
            email:"",
            eventName:"",
            freeText:""
    }
    return (<>
        <div>
            150 איש צפו ברשימה לחינה
        </div>
        <div>
            14 אירועים חדשים נפתחו השבוע
        </div>
    </>)
}
export default Statictics;