function Customer1(id,password,name,phone,email,status,approve,image)
{
   this.id=id;
   this.password=password;
   this.name=name;
   this.phone=phone;
   this.email=email;
   this.status=status;
   this.approve=approve;
   this.image=image;
}


export default Customer1;